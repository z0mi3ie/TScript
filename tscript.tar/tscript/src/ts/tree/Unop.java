//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//  UNOP ENUM
//  Kyle Vickers
//  
//  Public enum for unary operator names
//
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

package ts.tree;

public enum Unop {
  NOT,
  MINUS
}

