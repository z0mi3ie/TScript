#!/bin/bash

java -ea -jar ../../../build/lib/antlr.jar Tscript.g -no-listener

