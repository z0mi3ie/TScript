var a,b;

print "Single Assigns";
var c = 1;
var d = "hello i was assigned";
print c;
print d;

print "Multiple Assigns";
var e = "first", f = "second", g = "Third";
print e;
print f;
print g;

