//
// undeclared identifier is a run-time error
// this detects an error in the use of an identifier on the right-hand side
// of an assignment
//

var abc;

abc = 5;

print abc + def;

