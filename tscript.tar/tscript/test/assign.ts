//
// test simple assignment
//

var abc;

abc = 42;
print abc;

print abc = 42;

