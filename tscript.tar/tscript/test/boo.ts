var x;
var y;
x = true;
y = false;
print x;
print y;

var z;
x = 5;
y = 5;
z = x - y;
print z;

z = 0 - 5;
print z;

z = 100 / 10;
print z;

z = 5 / 5;
print z;

z = !false;
print z; 

z = !true;
print z; 

z = !!!true;
print z; 

x = 1;
y = 1;

print x;

z = 1==2;
print z;

z = 17 == 17;
print z;

z = true == true;
print z;

z = false == false;
print z;

z = true == false;
print z;

z = false == true;
print z;

print 777777777;

z = 1 < 2;
print z;

z = 2 < 1;
print z;

z = 5 > 4;
print z;

z = 4 > 5;
print z;

print 222222; 

z = 1 > 1;
print z;

z = 1 < 1;
print z;

z = 909090909090;
print z;

x = 1;
z = -x;
print z;

z = -(5+5);
print z;

x = false;
z = -x;
print z;

z = null;
print z;


z = 1111111111111;
print z;

x = .5;
y = .3;
z = x + y;
print z;

z = 0XA + 1;
print z;

var u;
print u;

u = "Hello world! I am a string!";
print u;
print "I AM A STRING WITH A PRINT COMMAND";
print "I am on one light\nI am on the next line!";
print "Yes!tabs>>> \t\t\t\t\t OVER HERE";

print "----Var Declaractions----";

