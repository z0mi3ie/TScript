//print = function (x) { console.log(x); };

var F;

//F = function () { return this; };
F = 42;

var i;

i = new F();
i.a = 42;

print (i.a);

