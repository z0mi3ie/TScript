//print = function (x) { console.log(x); };
x = 20;
print(x+y);  // read of undeclared ID is an error


