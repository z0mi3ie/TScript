//print = function (x) { console.log(x); };

//readln = function () {
//  var cnt = 0;
//  return function () {
//    if (cnt < 5) return "line " + ++cnt + "\n";
//    else return "";
//  };
//}();

var x;

x = readln();
while (x)
{
  print (x);
  x = readln();
}

print (x);

