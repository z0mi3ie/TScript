//print = function (x) { console.log(x); };
print (NaN);

