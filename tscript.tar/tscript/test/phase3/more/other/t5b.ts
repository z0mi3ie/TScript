// Node prints "undefined"
// Firefox prints 42, as I would expect

var x;
x = 42;

print (this.x);

