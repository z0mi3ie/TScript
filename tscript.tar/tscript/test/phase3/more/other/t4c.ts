//print = function (x) { console.log(x); };

var x;

//x = "//print = function (x) { console.log(x); };\n";
x = readln();

print(x);

