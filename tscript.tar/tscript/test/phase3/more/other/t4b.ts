//print = function (x) { console.log(x); };

var x;

x = 1;

if (isNaN(x))
{
  print (43);
}

x = NaN;

if (isNaN(x))
{
  print (42);
}

x = Infinity;

if (isNaN(x))
{
  print (43);
}

