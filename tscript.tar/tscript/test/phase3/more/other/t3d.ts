//print = function (x) { console.log(x); };
x = 20;
y = 22;
print(x+y);


