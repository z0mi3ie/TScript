var i;

i = new F();
i.a = 42;

print (i.a);

