this.x = 42;

print (x);

