//print = function (x) { console.log(x) };

var x;
x = 42;
print(this.x);

